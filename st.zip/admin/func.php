<?php
	require '../inc/db.php';
	
	function editList($id, $post){
		$list = R::load('list', $id);
		$list -> title = $post['title'];
		$list -> price = $post['price'];
		R::store($list);
	}
	
	function editMast($id, $post){
		$mast = R::load('masters', $id);
		$mast -> master = $post['master'];
		$mast -> branch = $post['branch'];
		$mast -> service = $post['service'];
		R::store($mast);
	}
	
	function delList($id){
		$delete = R::load('list', $id);
		R::trash($delete);
	}
	
	function delMast($id){
		$delete = R::load('masters', $id);
		R::trash($delete);
	}
	
	function addList($post){
		$list = R::dispense('list');
		$list -> title = $post['title'];
		$list -> price = $post['price'];
		R::store($list);
	}
	
	function addMast($post){
		$masters = R::dispense('masters');
		$masters -> master = $post['master'];
		$masters -> service = $post['service'];
		$masters -> branch = $post['branch'];
		R::store($masters);
	}
	
	function addWorks($post){
		$input_name = 'file';
		
		// Разрешенные расширения файлов.
		$allow = array();
		
		// Запрещенные расширения файлов.
		$deny = array(
		'phtml', 'php', 'php3', 'php4', 'php5', 'php6', 'php7', 'phps', 'cgi', 'pl', 'asp', 
		'aspx', 'shtml', 'shtm', 'htaccess', 'htpasswd', 'ini', 'log', 'sh', 'js', 'html', 
		'htm', 'css', 'sql', 'spl', 'scgi', 'fcgi'
		);
		
		// Директория куда будут загружаться файлы.
		$path = '../assets/img/works/';
		
		if (isset($_FILES[$input_name])) {
			// Проверим директорию для загрузки.
			if (!is_dir($path)) {
				mkdir($path, 0777, true);
			}
			
			// Преобразуем массив $_FILES в удобный вид для перебора в foreach.
			$files = array();
			$diff = count($_FILES[$input_name]) - count($_FILES[$input_name], COUNT_RECURSIVE);
			if ($diff == 0) {
				$files = array($_FILES[$input_name]);
				} else {
				foreach($_FILES[$input_name] as $k => $l) {
					foreach($l as $i => $v) {
						$files[$i][$k] = $v;
					}
				}		
			}	
			
			foreach ($files as $file) {
				$error = $success = '';
				
				// Проверим на ошибки загрузки.
				if (!empty($file['error']) || empty($file['tmp_name'])) {
					switch (@$file['error']) {
						case 1:
						case 2: $error = 'Превышен размер загружаемого файла.'; break;
						case 3: $error = 'Файл был получен только частично.'; break;
						case 4: $error = 'Файл не был загружен.'; break;
						case 6: $error = 'Файл не загружен - отсутствует временная директория.'; break;
						case 7: $error = 'Не удалось записать файл на диск.'; break;
						case 8: $error = 'PHP-расширение остановило загрузку файла.'; break;
						case 9: $error = 'Файл не был загружен - директория не существует.'; break;
						case 10: $error = 'Превышен максимально допустимый размер файла.'; break;
						case 11: $error = 'Данный тип файла запрещен.'; break;
						case 12: $error = 'Ошибка при копировании файла.'; break;
						default: $error = 'Файл не был загружен - неизвестная ошибка.'; break;
					}
					} elseif ($file['tmp_name'] == 'none' || !is_uploaded_file($file['tmp_name'])) {
					$error = 'Не удалось загрузить файл.';
					} else {
					// Оставляем в имени файла только буквы, цифры и некоторые символы.
					$pattern = "[^a-zа-яё0-9,~!@#%^-_\$\?\(\)\{\}\[\]\.]";
					$name = mb_eregi_replace($pattern, '-', $file['name']);
					$name = mb_ereg_replace('[-]+', '-', $name);
					
					// Т.к. есть проблема с кириллицей в названиях файлов (файлы становятся недоступны).
					// Сделаем их транслит:
					$converter = array(
					'а' => 'a',   'б' => 'b',   'в' => 'v',    'г' => 'g',   'д' => 'd',   'е' => 'e',
					'ё' => 'e',   'ж' => 'zh',  'з' => 'z',    'и' => 'i',   'й' => 'y',   'к' => 'k',
					'л' => 'l',   'м' => 'm',   'н' => 'n',    'о' => 'o',   'п' => 'p',   'р' => 'r',
					'с' => 's',   'т' => 't',   'у' => 'u',    'ф' => 'f',   'х' => 'h',   'ц' => 'c',
					'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',  'ь' => '',    'ы' => 'y',   'ъ' => '',
					'э' => 'e',   'ю' => 'yu',  'я' => 'ya', 
					
					'А' => 'A',   'Б' => 'B',   'В' => 'V',    'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
					'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',    'И' => 'I',   'Й' => 'Y',   'К' => 'K',
					'Л' => 'L',   'М' => 'M',   'Н' => 'N',    'О' => 'O',   'П' => 'P',   'Р' => 'R',
					'С' => 'S',   'Т' => 'T',   'У' => 'U',    'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
					'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',  'Ь' => '',    'Ы' => 'Y',   'Ъ' => '',
					'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
					);
					
					$name = strtr($name, $converter);
					$parts = pathinfo($name);
					
					if (empty($name) || empty($parts['extension'])) {
						$error = 'Недопустимое тип файла';
						} elseif (!empty($allow) && !in_array(strtolower($parts['extension']), $allow)) {
						$error = 'Недопустимый тип файла';
						} elseif (!empty($deny) && in_array(strtolower($parts['extension']), $deny)) {
						$error = 'Недопустимый тип файла';
						} else {
						// Чтобы не затереть файл с таким же названием, добавим префикс.
						$i = 0;
						$prefix = '';
						while (is_file($path . $parts['filename'] . $prefix . '.' . $parts['extension'])) {
							$prefix = '(' . ++$i . ')';
						}
						$name = $parts['filename'] . $prefix . '.' . $parts['extension'];
						
						// Перемещаем файл в директорию.
						if (move_uploaded_file($file['tmp_name'], $path . $name)) {
							// Далее можно сохранить название файла в БД и т.п.
							$success = 'Файл «' . $name . '» успешно загружен.';
							$works = R::dispense('works');
							$works -> photo = './assets/img/works/'.$name;
							R::store($works);
							} else {
							$error = 'Не удалось загрузить файл.';
						}
					}
				}
				
			}
		}
	}
	
	function delWorks($id){
		$delete = R::load('works', $id);
		unlink('.'.$delete->photo);
		R::trash($delete);
		header("Location: ./works.php");
	}
	
	
	if($_POST["action"] == "edit"){
		editList($_POST["id"], $_POST);
		header("Location: ./listedit.php?id=".$_POST['id']);
	}
	
	if($_POST["action"] == "editmast"){
		editMast($_POST["id"], $_POST);
		header("Location: ./masedit.php?id=".$_POST['id']);
	}
	
	if($_GET["action"] == "del"){
		delList($_GET["id"]);
		header("Location: ./services.php");
	}
	
	if($_GET["action"] == "delworks"){
		delWorks($_GET["id"]);
		header("Location: ./works.php");
	}
	
	if($_GET["action"] == "delmast"){
		delMast($_GET["id"]);
		header("Location: ./masters.php");
	}
	
	if($_POST["action"] == "add"){
		addList($_POST);
		header("Location: ./services.php");
	}
	
	if($_POST["action"] == "addmas"){
		addMast($_POST);
		header("Location: ./masters.php");
	}
	
	if($_POST["action"] == "addworks"){
		addWorks($_POST);
		header("Location: ./works.php");
	}
?>