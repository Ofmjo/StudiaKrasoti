<?php
	require '../inc/db.php';
	$masters = R::findAll('masters');
	
	if (isset($_SESSION['logged_user'])) :
?>
<!DOCTYPE html>
<!--
	This is a starter template page. Use this page to start your new project from
	scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>AdminLTE 3 | Управление мастерами</title>
		
		<!-- Google Font: Source Sans Pro -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
		<!-- Font Awesome Icons -->
		<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
		<!-- Theme style -->
		<link rel="stylesheet" href="dist/css/adminlte.min.css">
	</head>
	<body class="hold-transition layout-top-nav">
		<div class="wrapper">
			
			<!-- Navbar -->
			<nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
				<div class="container">
					<a href="/" class="navbar-brand">
						<img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
						<span class="brand-text font-weight-light">AdminLTE 3</span>
					</a>
					
					<button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					
					<div class="collapse navbar-collapse order-3" id="navbarCollapse">
						<!-- Left navbar links -->
						<ul class="navbar-nav">
							<li class="nav-item">
								<a href="index.php" class="nav-link">Панель управления</a>
							</li>
							<li class="nav-item">
								<a href="orders.php" class="nav-link">Все заказы</a>
							</li>
							<li class="nav-item">
								<a href="services.php" class="nav-link">Управление услугами</a>
							</li>
							<li class="nav-item">
								<a href="masters.php" class="nav-link active">Мастера</a>
							</li>
							<li class="nav-item">
								<a href="works.php" class="nav-link">Портфолио</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			<!-- /.navbar -->
			
			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Content Header (Page header) -->
				<div class="content-header">
					<div class="container">
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1 class="m-0"> Все мастера</h1>
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.container-fluid -->
				</div>
				<!-- /.content-header -->
				
				<!-- Main content -->
				<div class="content">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<div class="card">
									<div class="card-body">
										<a href="./masadd.php" class="btn btn-primary mb-2">Добавить мастера</a>
										<table id="example1" class="table table-bordered table-striped">
											<thead>
												<tr>
													<th style="width: 10px">#</th>
													<th>Мастер</th>
													<th>Специальность</th>
													<th>Действия</th>
												</tr>
											</thead>
											<tbody>
												<?php
													foreach ($masters as $m) {
														echo '<td>'.$m["id"].'</td>';
														echo '<td>'.$m["master"].'</td>';
														echo '<td>'.$m["branch"].'</td>';
														echo '
														<td style="width: 20px">
														<a href="./masedit.php?id='.$m["id"].'" title="Редактировать" class="mr-1"><i class="far fa-edit"></i></a>
														<a href="./func.php?action=delmast&id='.$m["id"].'" title="Удалить" class="mr-1"><i class="fas fa-times"></i></a>
														</td>
														';
														echo '</tr>';
													}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div><!-- /.card -->
						</div>
						
					</div>
					<!-- /.row -->
				</div><!-- /.container-fluid -->
			</div>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<!-- Main Footer -->
		<footer class="main-footer">
			<!-- To the right -->
			<div class="float-right d-none d-sm-inline">
				Anything you want
			</div>
			<!-- Default to the left -->
			<strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
		</footer>
	</div>
	<!-- ./wrapper -->
	
	<!-- REQUIRED SCRIPTS -->
	
	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
<?php else : ?>
<script>
	window.location.href = "./login.php";
</script>
<?php endif;  ?>