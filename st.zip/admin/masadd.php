<?php
	require '../inc/db.php';
	$services = R::findAll('list');
	
	if (isset($_SESSION['logged_user'])) :
?>
<!DOCTYPE html>
<!--
	This is a starter template page. Use this page to start your new project from
	scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>AdminLTE 3 | Добавление мастера</title>
		
		<!-- Google Font: Source Sans Pro -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
		<!-- Font Awesome Icons -->
		<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
		<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
		<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
		<!-- Theme style -->
		<link rel="stylesheet" href="dist/css/adminlte.min.css">
	</head>
	<body class="hold-transition layout-top-nav">
		<div class="wrapper">
			
			<!-- Navbar -->
			<nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
				<div class="container">
					<a href="/" class="navbar-brand">
						<img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
						<span class="brand-text font-weight-light">AdminLTE 3</span>
					</a>
					
					<button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					
					<div class="collapse navbar-collapse order-3" id="navbarCollapse">
						<!-- Left navbar links -->
						<ul class="navbar-nav">
							<li class="nav-item">
								<a href="index.php" class="nav-link">Панель управления</a>
							</li>
							<li class="nav-item">
								<a href="orders.php" class="nav-link">Все заказы</a>
							</li>
							<li class="nav-item">
								<a href="services.php" class="nav-link">Управление услугами</a>
							</li>
							<li class="nav-item">
								<a href="masters.php" class="nav-link active">Мастера</a>
							</li>
							<li class="nav-item">
								<a href="works.php" class="nav-link">Портфолио</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			<!-- /.navbar -->
			
			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Content Header (Page header) -->
				<div class="content-header">
					<div class="container">
						<div class="row mb-2">
							<div class="col-sm-6">
								<h1 class="m-0"> Добавление мастера</h1>
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.container-fluid -->
				</div>
				<!-- /.content-header -->
				
				<!-- Main content -->
				<div class="content">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<div class="card card-primary">
									<div class="card-body">
										<form id="list" method="post" action="./func.php">
											<div class="form-group">
												<input type="hidden" name="action" class="form-control" value="addmas">
											</div>
											<div class="form-group">
												<label for="master">Имя мастера</label>
												<input type="text" id="master" name="master" class="form-control">
											</div>
											<div class="form-group">
												<label for="branch">Специальность</label>
												<input type="text" id="branch" name="branch" class="form-control">
											</div>
											<div class="form-group">
												<label for="master">Предоставляемые услуги (Пример: 1; 1,3; 1,2,4)</label>
												<input type="text" id="service" name="service" class="form-control">
												<br>
												<a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
													Показать ID всех услуг
												</a>
												<br>
												<div class="collapse" id="collapseExample">
													<div class="card card-body">
														<?php
															foreach ($services as $s) {
																echo '<small>'.$s["id"]. ' - '.$s["title"].'</small>';
															}
														?>
													</div>
												</div>
											</div>
											<div class="form-group">
												<button type="submit" class="btn btn-success">Сохранить</button>
											</div>
										</form>
									</div>
									
								</div>
							</div><!-- /.card -->
						</div>
						
					</div>
					<!-- /.row -->
				</div><!-- /.container-fluid -->
				<!-- /.content -->
			</div>
			<!-- /.content-wrapper -->
			
			<!-- Main Footer -->
			<footer class="main-footer">
				<!-- To the right -->
				<div class="float-right d-none d-sm-inline">
					Anything you want
				</div>
				<!-- Default to the left -->
				<strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
			</footer>
		</div>
		<!-- ./wrapper -->
		
		<!-- REQUIRED SCRIPTS -->
		
		<!-- jQuery -->
		<script src="plugins/jquery/jquery.min.js"></script>
		<!-- Bootstrap 4 -->
		<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
		<!-- AdminLTE App -->
		<script src="dist/js/adminlte.min.js"></script>
		<script src="plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
		<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
		<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
		<script>
			$("#list").on("submit", function(){
				alert("Мастер добавлен!");
			});
		</script>
	</body>
</html>
<?php else : ?>
<script>
	window.location.href = "./login.php";
</script>
<?php endif;  ?>